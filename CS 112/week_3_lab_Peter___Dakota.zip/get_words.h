/*----
  header file for function: x

  by: Peter Ramos, Dakota Donner
  last modified: 2/4/22
----*/

#ifndef GET_WORDS_H    // replace X with the NAME of your function in all-caps
#define GET_WORDS_H
#include <string>

using namespace std;

int get_words(string file_name, string word_array[], int size);

#endif

