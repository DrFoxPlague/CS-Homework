/*----
  header file for function: x

  by: Peter Ramos, Dakota Donner
  last modified: 2/4/22
----*/

#ifndef WORDS_TO_FILE_H    // replace X with the NAME of your function in all-caps
#define WORDS_TO_FILE_H
#include <string>

using namespace std;

int words_to_file(string file_name, int num_of_words);

#endif

