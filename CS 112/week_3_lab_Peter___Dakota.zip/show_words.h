/*----
  header file for function: x

  by: Peter Ramos, Dakota Donner
  last modified: 2/4/22
----*/

#ifndef SHOW_WORDS_H    // replace X with the NAME of your function in all-caps
#define SHOW_WORDS_H
#include <string>

using namespace std;

int show_words(string word_array[], int size);

#endif

