/*----
  header file for function: x

  by: Peter Ramos & Dakota Donner
  last modified: 2-25-2022
----*/

#ifndef ACCELERATE_H
#define ACCELERATE_H

void accelerate(double &des_speed);

#endif