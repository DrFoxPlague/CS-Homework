/*----
  header file for function: five_letter_word

  by: Dakota Donner
  last modified: 1-28-2022
----*/

#ifndef FIVE_LETTER_WORD_H
#define FIVE_LETTER_WORD_H

#include <string>
using namespace std;

bool five_letter_word(string des_word);

#endif