/*----
  header file for function: ask_for_word

  by: Dakota Donner
  last modified: 1-28-2022
----*/

#ifndef ASK_FOR_WORD_H
#define ASK_FOR_WORD_H

#include <string>
using namespace std;

string ask_for_word(string user_name);

#endif