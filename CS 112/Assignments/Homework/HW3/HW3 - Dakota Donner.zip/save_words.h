/*----
  header file for function: save_words

  by: Dakota Donner
  last modified: 2-11-2022
----*/

#ifndef SAVE_WORDS_H
#define SAVE_WORDS_H

#include <string>
using namespace std;

void save_words(string word_arr[], int arr_size, string file_name);

#endif