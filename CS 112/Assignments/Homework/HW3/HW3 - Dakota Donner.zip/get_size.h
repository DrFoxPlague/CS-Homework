/*----
  header file for function: get_size

  by: Dakota Donner
  last modified: 2-11-2022
----*/

#ifndef GET_SIZE_H
#define GET_SIZE_H

#include <string>
using namespace std;

int get_size(string name_of_file);

#endif