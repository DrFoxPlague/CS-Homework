/*----
  header file for function: guess_match

  by: Sharon Tuttle
  last modified: 2022-01-27
----*/

#ifndef GUESS_MATCH_H
#define GUESS_MATCH_H

#include <string>
using namespace std;

string guess_match(string word_of_day, string word_guess);

#endif