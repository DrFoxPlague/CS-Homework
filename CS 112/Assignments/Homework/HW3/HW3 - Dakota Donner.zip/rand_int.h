/*----
  header file for function: rand_int

  by: Sharon Tuttle
  last modified: 2022-02-04
----*/

#ifndef RAND_INT_H    
#define RAND_INT_H

int rand_int(int desired_min, int desired_max);

#endif