/*----
  header file for function: show_multiples

  by: Dakota Donner
  last modified: 2-4-2022
----*/

#ifndef SHOW_MULTIPLES_H
#define SHOW_MULTIPLES_H

int show_multiples(int chsn_num);

#endif