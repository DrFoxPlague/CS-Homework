/*----
  header file for function: hide_letters.h

  by: Dakota Donner
  last modified: 2-4-2022
----*/

#ifndef HIDE_LETTERS_H
#define HIDE_LETTERS_H

#include <string>
using namespace std;

string hide_letters(string des_phrase);

#endif