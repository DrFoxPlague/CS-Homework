/*----
  header file for function: get_winner

  by: Dakota Donner
  last modified: 2-4-2022
----*/

#ifndef GET_WINNER_H
#define GET_WINNER_H

int get_winner(char p1_choice, char p2_choice);

#endif