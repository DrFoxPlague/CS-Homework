/*----
  header file for function: is_letter

  by: Sharon Tuttle
  last modified: 2022-01-28
----*/

#ifndef IS_LETTER_H    
#define IS_LETTER_H

bool is_letter(char a_char);

#endif