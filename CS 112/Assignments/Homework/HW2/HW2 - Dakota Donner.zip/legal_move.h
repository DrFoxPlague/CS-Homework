/*----
  header file for function: legal_move

  by: Dakota Donner
  last modified: 2-4-2022
----*/

#ifndef LEGAL_MOVE_H
#define LEGAL_MOVE_H

bool legal_move(char des_move_char);

#endif