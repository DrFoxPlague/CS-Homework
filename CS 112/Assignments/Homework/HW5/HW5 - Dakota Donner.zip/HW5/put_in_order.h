/*----
  header file for function: put_in_order

  by: Dakota Donner
  last modified: 3-4-2022
----*/

#ifndef PUT_IN_ORDER_H
#define PUT_IN_ORDER_H

void put_in_order(double &num_1, double &num_2);

#endif