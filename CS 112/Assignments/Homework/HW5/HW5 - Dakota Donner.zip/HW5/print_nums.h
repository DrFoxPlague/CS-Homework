/*----
  header file for function: print_nums

  by: Sharon Tuttle
  last modified: 2022-02-03
----*/

#ifndef PRINT_NUMS_H
#define PRINT_NUMS_H

void print_nums(const double my_nums[], int size);

#endif