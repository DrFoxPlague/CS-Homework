/*----
  header file for function: rand_factor

  by: Sharon Tuttle
  last modified: 2022-03-04
----*/

#ifndef RAND_FACTOR_H
#define RAND_FACTOR_H

double rand_factor();

#endif