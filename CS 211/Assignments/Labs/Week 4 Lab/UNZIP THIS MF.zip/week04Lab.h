/* 
 * File:   Lab04.h
 * Author: David
 *
 * Modified on 13 Sep 2022
 */

#ifndef LAB04_H
#define LAB04_H

int sumDownBy2(unsigned int n);

int recursiveMult(unsigned int j, unsigned int k);

double geometricSum(unsigned int n);

#endif /* LAB04_H */

